<?php
require_once __DIR__ . '/includes/header.php';
?>

<div class="container py-5">
    <div class="row">
        <div class="col-lg-8 mx-auto">
            <div class="card shadow">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0">من نحن</h4>
                </div>
                <div class="card-body">
                    <div class="text-center mb-4">
                        <img src="assets/images/logo.png" alt="KREZMO" class="img-fluid mb-3" style="max-height: 150px;">
                        <h2 class="text-primary">KREZMO</h2>
                        <p class="lead text-muted">منصة إعلانات مبوبة سورية متكاملة</p>
                    </div>

                    <div class="mb-4">
                        <h5 class="text-primary">رؤيتنا</h5>
                        <p>نسعى لأن نكون المنصة الأولى للإعلانات المبوبة في سوريا، حيث يمكن للجميع بيع وشراء وتبادل السلع والخدمات بكل سهولة وأمان.</p>
                    </div>

                    <div class="mb-4">
                        <h5 class="text-primary">رسالتنا</h5>
                        <p>توفير منصة سهلة الاستخدام وآمنة تمكن المستخدمين من التواصل وتبادل المنفعة، مع الحفاظ على أعلى معايير الجودة والموثوقية.</p>
                    </div>

                    <div class="mb-4">
                        <h5 class="text-primary">قيمنا</h5>
                        <ul class="list-unstyled">
                            <li class="mb-2">
                                <i class="fas fa-check-circle text-success me-2"></i>
                                <strong>الموثوقية:</strong> نضمن مصداقية الإعلانات والمستخدمين
                            </li>
                            <li class="mb-2">
                                <i class="fas fa-check-circle text-success me-2"></i>
                                <strong>السهولة:</strong> واجهة بسيطة وسهلة الاستخدام
                            </li>
                            <li class="mb-2">
                                <i class="fas fa-check-circle text-success me-2"></i>
                                <strong>الأمان:</strong> حماية بيانات المستخدمين ومعلوماتهم
                            </li>
                            <li class="mb-2">
                                <i class="fas fa-check-circle text-success me-2"></i>
                                <strong>الشفافية:</strong> سياسات واضحة وشفافة
                            </li>
                        </ul>
                    </div>

                    <div class="mb-4">
                        <h5 class="text-primary">خدماتنا</h5>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <div class="card h-100">
                                    <div class="card-body">
                                        <i class="fas fa-tag text-primary fa-2x mb-3"></i>
                                        <h6>إعلانات مبوبة</h6>
                                        <p class="small text-muted">نشر وبيع وشراء مختلف السلع والخدمات</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <div class="card h-100">
                                    <div class="card-body">
                                        <i class="fas fa-comments text-primary fa-2x mb-3"></i>
                                        <h6>تواصل مباشر</h6>
                                        <p class="small text-muted">تواصل مباشر بين البائع والمشتري</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <div class="card h-100">
                                    <div class="card-body">
                                        <i class="fas fa-shield-alt text-primary fa-2x mb-3"></i>
                                        <h6>حماية المستخدمين</h6>
                                        <p class="small text-muted">نظام تقييم ومراقبة للإعلانات والمستخدمين</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <div class="card h-100">
                                    <div class="card-body">
                                        <i class="fas fa-mobile-alt text-primary fa-2x mb-3"></i>
                                        <h6>توافق مع الأجهزة</h6>
                                        <p class="small text-muted">تصميم متجاوب يعمل على جميع الأجهزة</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?> 