<?php
require_once 'config.php';

// Check if user is logged in
if(!is_logged_in()) {
    redirect('login.php');
}

// Get current user
$current_user = get_current_user();
if(!$current_user) {
    session_destroy();
    redirect('login.php');
}

// Get categories
try {
    $stmt = $pdo->query("SELECT * FROM categories WHERE parent_id IS NULL ORDER BY name");
    $main_categories = $stmt->fetchAll();
} catch(PDOException $e) {
    error_log("Error fetching categories: " . $e->getMessage());
    $main_categories = [];
}

// Handle form submission
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = clean($_POST['title']);
    $description = clean($_POST['description']);
    $price = clean($_POST['price']);
    $category_id = clean($_POST['category_id']);
    $location = clean($_POST['location']);
    
    // Validate input
    $errors = [];
    if(empty($title)) $errors[] = "عنوان الإعلان مطلوب";
    if(empty($description)) $errors[] = "وصف الإعلان مطلوب";
    if(empty($price)) $errors[] = "السعر مطلوب";
    if(empty($category_id)) $errors[] = "التصنيف مطلوب";
    if(empty($location)) $errors[] = "الموقع مطلوب";
    
    // Validate category exists
    try {
        $stmt = $pdo->prepare("SELECT id FROM categories WHERE id = ?");
        $stmt->execute([$category_id]);
        if(!$stmt->fetch()) {
            $errors[] = "التصنيف المختار غير صالح";
        }
    } catch(PDOException $e) {
        error_log("Error validating category: " . $e->getMessage());
        $errors[] = "حدث خطأ في التحقق من التصنيف";
    }
    
    // Handle media upload
    $images = [];
    $videos = [];
    
    // Handle images
    if(!empty($_FILES['images']['name'][0])) {
        $upload_dir = 'uploads/listings/images/';
        if(!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        foreach($_FILES['images']['tmp_name'] as $key => $tmp_name) {
            if($_FILES['images']['error'][$key] === UPLOAD_ERR_OK) {
                $file_name = $_FILES['images']['name'][$key];
                $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
                
                // Check if file is an image
                if(in_array($file_ext, ['jpg', 'jpeg', 'png', 'gif'])) {
                    $new_file_name = uniqid() . '.' . $file_ext;
                    $file_path = $upload_dir . $new_file_name;
                    
                    if(move_uploaded_file($tmp_name, $file_path)) {
                        $images[] = $file_path;
                    } else {
                        $errors[] = "فشل في رفع الصورة: " . $file_name;
                    }
                } else {
                    $errors[] = "نوع الملف غير مدعوم للصور. الأنواع المدعومة: JPG, JPEG, PNG, GIF";
                }
            } else {
                $errors[] = "خطأ في رفع الصورة: " . $_FILES['images']['name'][$key];
            }
        }
    }
    
    // Handle videos
    if(!empty($_FILES['videos']['name'][0])) {
        $upload_dir = 'uploads/listings/videos/';
        if(!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        foreach($_FILES['videos']['tmp_name'] as $key => $tmp_name) {
            if($_FILES['videos']['error'][$key] === UPLOAD_ERR_OK) {
                $file_name = $_FILES['videos']['name'][$key];
                $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
                
                // Check if file is a video
                if(in_array($file_ext, ['mp4', 'webm', 'ogg'])) {
                    $new_file_name = uniqid() . '.' . $file_ext;
                    $file_path = $upload_dir . $new_file_name;
                    
                    if(move_uploaded_file($tmp_name, $file_path)) {
                        $videos[] = $file_path;
                    } else {
                        $errors[] = "فشل في رفع الفيديو: " . $file_name;
                    }
                } else {
                    $errors[] = "نوع الملف غير مدعوم للفيديوهات. الأنواع المدعومة: MP4, WEBM, OGG";
                }
            } else {
                $errors[] = "خطأ في رفع الفيديو: " . $_FILES['videos']['name'][$key];
            }
        }
    }
    
    if(empty($errors)) {
        try {
            $pdo->beginTransaction();
            
            // Insert listing
            $stmt = $pdo->prepare("
                INSERT INTO listings (user_id, title, description, price, category_id, location, created_at)
                VALUES (?, ?, ?, ?, ?, ?, NOW())
            ");
            $stmt->execute([
                $_SESSION['user_id'],
                $title,
                $description,
                $price,
                $category_id,
                $location
            ]);
            
            $listing_id = $pdo->lastInsertId();
            
            // Insert images
            if(!empty($images)) {
                $stmt = $pdo->prepare("
                    INSERT INTO listing_images (listing_id, image_url, is_primary, created_at)
                    VALUES (?, ?, ?, NOW())
                ");
                
                foreach($images as $key => $image) {
                    $stmt->execute([
                        $listing_id,
                        $image,
                        $key === 0 ? 1 : 0 // First image is primary
                    ]);
                }
            }
            
            // Insert videos
            if(!empty($videos)) {
                $stmt = $pdo->prepare("
                    INSERT INTO listing_videos (listing_id, video_url, created_at)
                    VALUES (?, ?, NOW())
                ");
                
                foreach($videos as $video) {
                    $stmt->execute([
                        $listing_id,
                        $video
                    ]);
                }
            }
            
            $pdo->commit();
            redirect('listing.php?id=' . $listing_id);
            
        } catch(Exception $e) {
            $pdo->rollBack();
            error_log("Error creating listing: " . $e->getMessage());
            $errors[] = "حدث خطأ أثناء إضافة الإعلان";
        }
    }
}

require_once 'includes/header.php';
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow">
                <div class="card-body">
                    <h2 class="card-title text-center mb-4">إضافة إعلان جديد</h2>
                    
                    <?php if(!empty($errors)): ?>
                        <div class="alert alert-danger">
                            <ul class="mb-0">
                                <?php foreach($errors as $error): ?>
                                    <li><?php echo $error; ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    
                    <form method="POST" action="" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="title" class="form-label">عنوان الإعلان</label>
                            <input type="text" class="form-control" id="title" name="title" required
                                   value="<?php echo isset($_POST['title']) ? htmlspecialchars($_POST['title']) : ''; ?>">
                        </div>
                        
                        <div class="mb-3">
                            <label for="description" class="form-label">وصف الإعلان</label>
                            <textarea class="form-control" id="description" name="description" rows="5" required><?php echo isset($_POST['description']) ? htmlspecialchars($_POST['description']) : ''; ?></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label for="price" class="form-label">السعر</label>
                            <input type="number" class="form-control" id="price" name="price" required
                                   value="<?php echo isset($_POST['price']) ? htmlspecialchars($_POST['price']) : ''; ?>">
                        </div>
                        
                        <div class="mb-3">
                            <label for="category_id" class="form-label">التصنيف</label>
                            <select class="form-select" id="category_id" name="category_id" required>
                                <option value="">اختر التصنيف</option>
                                <?php foreach($main_categories as $category): ?>
                                    <option value="<?php echo $category['id']; ?>" 
                                            <?php echo (isset($_POST['category_id']) && $_POST['category_id'] == $category['id']) ? 'selected' : ''; ?>>
                                        <?php echo $category['name']; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label for="location" class="form-label">الموقع</label>
                            <input type="text" class="form-control" id="location" name="location" required
                                   value="<?php echo isset($_POST['location']) ? htmlspecialchars($_POST['location']) : ''; ?>">
                        </div>
                        
                        <div class="mb-3">
                            <label for="images" class="form-label">صور الإعلان</label>
                            <input type="file" class="form-control" id="images" name="images[]" multiple accept="image/*">
                            <small class="text-muted">يمكنك اختيار أكثر من صورة. الصورة الأولى ستكون الصورة الرئيسية. الأنواع المدعومة: JPG, JPEG, PNG, GIF</small>
                        </div>
                        
                        <div class="mb-3">
                            <label for="videos" class="form-label">فيديوهات الإعلان</label>
                            <input type="file" class="form-control" id="videos" name="videos[]" multiple accept="video/*">
                            <small class="text-muted">يمكنك اختيار أكثر من فيديو. الأنواع المدعومة: MP4, WEBM, OGG</small>
                        </div>
                        
                        <div class="text-center">
                            <button type="submit" class="btn btn-primary">إضافة الإعلان</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?> 