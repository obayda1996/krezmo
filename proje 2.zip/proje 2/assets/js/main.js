ة// Wait for the DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    });

    // Initialize popovers
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'))
    var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl)
    });

    // Image preview for file inputs
    const imageInputs = document.querySelectorAll('.image-input');
    imageInputs.forEach(input => {
        input.addEventListener('change', function(e) {
            const preview = document.querySelector(this.dataset.preview);
            if (preview) {
                preview.innerHTML = '';
                [...this.files].forEach(file => {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        const img = document.createElement('img');
                        img.src = e.target.result;
                        img.classList.add('img-thumbnail', 'm-1');
                        img.style.maxHeight = '150px';
                        preview.appendChild(img);
                    }
                    reader.readAsDataURL(file);
                });
            }
        });
    });

    // Price formatter
    const priceInputs = document.querySelectorAll('.price-input');
    priceInputs.forEach(input => {
        input.addEventListener('input', function(e) {
            let value = this.value.replace(/[^\d]/g, '');
            if (value) {
                value = parseInt(value).toLocaleString('ar-SY');
                this.value = value;
            }
        });
    });

    // Search form submission
    const searchForm = document.querySelector('.search-form');
    if (searchForm) {
        searchForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const query = this.querySelector('input').value.trim();
            if (query) {
                window.location.href = `${window.location.origin}/search.php?q=${encodeURIComponent(query)}`;
            }
        });
    }

    // Favorite button functionality
    const favoriteButtons = document.querySelectorAll('.favorite-btn');
    favoriteButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const listingId = this.dataset.listingId;
            if (listingId) {
                fetch('/ajax/toggle-favorite.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ listing_id: listingId })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        this.classList.toggle('active');
                        const icon = this.querySelector('i');
                        if (icon) {
                            icon.classList.toggle('fas');
                            icon.classList.toggle('far');
                        }
                    }
                })
                .catch(error => console.error('Error:', error));
            }
        });
    });

    // Message form submission
    const messageForm = document.querySelector('.message-form');
    if (messageForm) {
        messageForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            fetch('/ajax/send-message.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const messageList = document.querySelector('.message-list');
                    if (messageList) {
                        const messageHtml = `
                            <div class="message-item sent">
                                <div class="message-content">
                                    ${data.message}
                                </div>
                                <div class="message-time">
                                    ${data.time}
                                </div>
                            </div>
                        `;
                        messageList.insertAdjacentHTML('beforeend', messageHtml);
                        this.reset();
                    }
                }
            })
            .catch(error => console.error('Error:', error));
        });
    }

    // Category filter
    const categoryFilter = document.querySelector('.category-filter');
    if (categoryFilter) {
        categoryFilter.addEventListener('change', function() {
            const category = this.value;
            if (category) {
                window.location.href = `${window.location.origin}/category.php?name=${encodeURIComponent(category)}`;
            }
        });
    }

    // Price range filter
    const priceRange = document.querySelector('.price-range');
    if (priceRange) {
        const minPrice = document.querySelector('#min-price');
        const maxPrice = document.querySelector('#max-price');
        
        priceRange.addEventListener('input', function() {
            const value = this.value;
            const min = parseInt(this.min);
            const max = parseInt(this.max);
            const percent = ((value - min) / (max - min)) * 100;
            this.style.background = `linear-gradient(to right, var(--primary-color) 0%, var(--primary-color) ${percent}%, #ddd ${percent}%, #ddd 100%)`;
        });
    }

    // Mobile menu toggle
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    const mobileMenu = document.querySelector('.mobile-menu');
    if (mobileMenuToggle && mobileMenu) {
        mobileMenuToggle.addEventListener('click', function() {
            mobileMenu.classList.toggle('active');
            this.classList.toggle('active');
        });
    }

    // Back to top button
    const backToTop = document.querySelector('.back-to-top');
    if (backToTop) {
        window.addEventListener('scroll', function() {
            if (window.pageYOffset > 300) {
                backToTop.classList.add('show');
            } else {
                backToTop.classList.remove('show');
            }
        });

        backToTop.addEventListener('click', function(e) {
            e.preventDefault();
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }
}); 