<?php
require_once __DIR__ . '/includes/header.php';

// Get category ID from URL
$category_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Get category details
try {
    $stmt = $pdo->prepare("SELECT * FROM categories WHERE id = ?");
    $stmt->execute([$category_id]);
    $category = $stmt->fetch();
    
    if (!$category) {
        // Category not found
        header("Location: index.php");
        exit();
    }
    
    // Get subcategories
    $stmt = $pdo->prepare("SELECT * FROM categories WHERE parent_id = ? ORDER BY name");
    $stmt->execute([$category_id]);
    $subcategories = $stmt->fetchAll();
    
    // Get listings for this category
    $stmt = $pdo->prepare("
        SELECT l.*, c.name as category_name, u.username,
               (SELECT image_url FROM listing_images WHERE listing_id = l.id AND is_primary = 1 LIMIT 1) as image_url
        FROM listings l
        JOIN categories c ON l.category_id = c.id
        JOIN users u ON l.user_id = u.id
        WHERE l.category_id = ? OR c.parent_id = ?
        ORDER BY l.created_at DESC
    ");
    $stmt->execute([$category_id, $category_id]);
    $listings = $stmt->fetchAll();
    
} catch(PDOException $e) {
    error_log("Error in category.php: " . $e->getMessage());
    die("عذراً، حدث خطأ أثناء تحميل التصنيف. يرجى المحاولة لاحقاً.");
}
?>

<div class="container py-5">
    <div class="row">
        <!-- Main Content -->
        <div class="col-md-9">
            <!-- Category Header -->
            <div class="card shadow mb-4">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0">
                        <i class="fas fa-folder me-2"></i>
                        <?php echo htmlspecialchars($category['name']); ?>
                    </h4>
                </div>
                <div class="card-body">
                    <?php if (!empty($category['description'])): ?>
                        <p class="text-muted"><?php echo htmlspecialchars($category['description']); ?></p>
                    <?php endif; ?>
                    
                    <?php if (!empty($subcategories)): ?>
                        <h5 class="mb-3">التصنيفات الفرعية:</h5>
                        <div class="row">
                            <?php foreach($subcategories as $subcategory): ?>
                                <div class="col-md-4 mb-3">
                                    <a href="category.php?id=<?php echo $subcategory['id']; ?>" 
                                       class="btn btn-outline-primary w-100">
                                        <i class="fas fa-folder me-2"></i>
                                        <?php echo htmlspecialchars($subcategory['name']); ?>
                                    </a>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <hr>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Listings -->
            <div class="card shadow">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">الإعلانات في هذا التصنيف</h5>
                </div>
                <div class="card-body">
                    <?php if (empty($listings)): ?>
                        <div class="alert alert-info">
                            لا توجد إعلانات في هذا التصنيف حالياً.
                        </div>
                    <?php else: ?>
                        <div class="row">
                            <?php foreach($listings as $listing): ?>
                                <div class="col-md-6 mb-4">
                                    <div class="card h-100">
                                        <img src="<?php echo $listing['image_url'] ?: 'assets/images/no-image.jpg'; ?>" 
                                             class="card-img-top" alt="<?php echo $listing['title']; ?>"
                                             style="height: 200px; object-fit: cover;">
                                        <div class="card-body">
                                            <h5 class="card-title"><?php echo htmlspecialchars($listing['title']); ?></h5>
                                            <p class="card-text text-primary mb-2">
                                                <?php echo number_format($listing['price']); ?> ل.س
                                            </p>
                                            <p class="card-text text-muted small mb-2">
                                                <i class="fas fa-tag me-1"></i> 
                                                <?php echo htmlspecialchars($listing['category_name']); ?>
                                            </p>
                                            <p class="card-text text-muted small mb-2">
                                                <i class="fas fa-user me-1"></i> 
                                                <?php echo htmlspecialchars($listing['username']); ?>
                                            </p>
                                            <p class="card-text text-muted small mb-3">
                                                <i class="fas fa-calendar me-1"></i> 
                                                <?php echo date('Y/m/d', strtotime($listing['created_at'])); ?>
                                            </p>
                                            <a href="listing.php?id=<?php echo $listing['id']; ?>" 
                                               class="btn btn-primary w-100">
                                                عرض التفاصيل
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Sidebar -->
        <div class="col-md-3">
            <!-- Breadcrumb -->
            <div class="card shadow mb-4">
                <div class="card-body">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0">
                            <li class="breadcrumb-item">
                                <a href="index.php">الرئيسية</a>
                            </li>
                            <?php if ($category['parent_id']): ?>
                                <?php
                                $stmt = $pdo->prepare("SELECT * FROM categories WHERE id = ?");
                                $stmt->execute([$category['parent_id']]);
                                $parent = $stmt->fetch();
                                if ($parent):
                                ?>
                                    <li class="breadcrumb-item">
                                        <a href="category.php?id=<?php echo $parent['id']; ?>">
                                            <?php echo htmlspecialchars($parent['name']); ?>
                                        </a>
                                    </li>
                                <?php endif; ?>
                            <?php endif; ?>
                            <li class="breadcrumb-item active" aria-current="page">
                                <?php echo htmlspecialchars($category['name']); ?>
                            </li>
                        </ol>
                    </nav>
                </div>
            </div>
            
            <!-- Related Categories -->
            <?php if ($category['parent_id']): ?>
                <div class="card shadow mb-4">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">التصنيفات المتعلقة</h5>
                    </div>
                    <div class="list-group list-group-flush">
                        <?php
                        $stmt = $pdo->prepare("
                            SELECT * FROM categories 
                            WHERE parent_id = ? AND id != ? 
                            ORDER BY name
                        ");
                        $stmt->execute([$category['parent_id'], $category_id]);
                        $related_categories = $stmt->fetchAll();
                        
                        foreach($related_categories as $related):
                        ?>
                            <a href="category.php?id=<?php echo $related['id']; ?>" 
                               class="list-group-item list-group-item-action">
                                <i class="fas fa-folder me-2"></i>
                                <?php echo htmlspecialchars($related['name']); ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?> 