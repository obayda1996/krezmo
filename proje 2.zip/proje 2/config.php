<?php
// Start session at the very beginning
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Database Configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'u631344896_krezmo');
define('DB_PASS', '@Ab095241');
define('DB_NAME', 'u631344896_krezmo');

// Site Configuration
define('SITE_NAME', 'KREZMO');
define('SITE_URL', 'https://krezmo.com');
define('SITE_DESCRIPTION', 'منصة إعلانات مبوبة سورية متكاملة');
define('ADMIN_EMAIL', 'info@krezmo.com');
define('ADMIN_PHONE', '+905340141757');

// Error Reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database Connection
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
        ]
    );
    
    // Test the connection
    $pdo->query("SELECT 1");
    
} catch(PDOException $e) {
    // Log detailed error information
    error_log("Database Connection Error Details:");
    error_log("Error Code: " . $e->getCode());
    error_log("Error Message: " . $e->getMessage());
    error_log("DSN: " . "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4");
    
    // Show user-friendly message
    die("عذراً، حدث خطأ في الاتصال بقاعدة البيانات. يرجى المحاولة لاحقاً.");
}

// Helper Functions
function clean($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

function redirect($url) {
    if (!headers_sent()) {
        header("Location: " . $url);
        exit();
    } else {
        echo '<script>window.location.href="' . $url . '";</script>';
        echo '<noscript><meta http-equiv="refresh" content="0;url=' . $url . '"></noscript>';
        exit();
    }
}

function is_logged_in() {
    return isset($_SESSION['user_id']);
}

if (!function_exists('get_current_user')) {
    function get_current_user() {
        if (!is_logged_in()) {
            return null;
        }
        
        global $pdo;
        $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        return $stmt->fetch();
    }
}

// Create required directories if they don't exist
$directories = [
    'uploads',
    'uploads/listings',
    'uploads/listings/images',
    'uploads/listings/videos',
    'uploads/profiles'
];

foreach($directories as $dir) {
    if(!file_exists($dir)) {
        mkdir($dir, 0777, true);
    }
}

// Set default timezone
date_default_timezone_set('Asia/Damascus');

// Set maximum upload size
ini_set('upload_max_filesize', '10M');
ini_set('post_max_size', '10M');
ini_set('max_execution_time', 300);
ini_set('max_input_time', 300);

// Set character encoding
mb_internal_encoding('UTF-8');
mb_http_output('UTF-8');
mb_regex_encoding('UTF-8');

// Set HTTP headers for character encoding
header('Content-Type: text/html; charset=UTF-8');
?> 