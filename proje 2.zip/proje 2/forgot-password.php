ذ<?php
require_once __DIR__ . '/includes/header.php';

$success = false;
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = clean($_POST['email'] ?? '');
    
    if (empty($email)) {
        $error = 'يرجى إدخال البريد الإلكتروني';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'يرجى إدخال بريد إلكتروني صحيح';
    } else {
        // Check if email exists
        $stmt = $pdo->prepare("SELECT id, username FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        
        if ($user) {
            // Generate reset token
            $token = bin2hex(random_bytes(32));
            $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));
            
            // Store token in database
            $stmt = $pdo->prepare("INSERT INTO password_resets (user_id, token, expires_at) VALUES (?, ?, ?)");
            $stmt->execute([$user['id'], $token, $expires]);
            
            // Send reset email
            $reset_link = SITE_URL . '/reset-password.php?token=' . $token;
            $to = $email;
            $subject = 'استعادة كلمة المرور - ' . SITE_NAME;
            $message = "
                <html dir='rtl'>
                <head>
                    <title>استعادة كلمة المرور</title>
                </head>
                <body>
                    <h2>مرحباً {$user['username']}</h2>
                    <p>لقد تلقينا طلباً لاستعادة كلمة المرور الخاصة بك.</p>
                    <p>يمكنك النقر على الرابط التالي لإعادة تعيين كلمة المرور:</p>
                    <p><a href='{$reset_link}'>{$reset_link}</a></p>
                    <p>ينتهي هذا الرابط خلال ساعة واحدة.</p>
                    <p>إذا لم تطلب استعادة كلمة المرور، يمكنك تجاهل هذا البريد الإلكتروني.</p>
                    <br>
                    <p>مع تحيات،<br>فريق " . SITE_NAME . "</p>
                </body>
                </html>
            ";
            
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
            $headers .= "From: " . SITE_NAME . " <" . ADMIN_EMAIL . ">" . "\r\n";
            
            if (mail($to, $subject, $message, $headers)) {
                $success = true;
            } else {
                $error = 'حدث خطأ أثناء إرسال البريد الإلكتروني. يرجى المحاولة لاحقاً.';
            }
        } else {
            // Don't reveal if email exists or not
            $success = true;
        }
    }
}
?>

<div class="container py-5">
    <div class="row">
        <div class="col-lg-6 mx-auto">
            <div class="card shadow">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0">استعادة كلمة المرور</h4>
                </div>
                <div class="card-body">
                    <?php if ($success): ?>
                        <div class="alert alert-success">
                            <i class="fas fa-check-circle me-2"></i>
                            إذا كان البريد الإلكتروني مسجلاً في نظامنا، سيتم إرسال رابط إعادة تعيين كلمة المرور إليه.
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($error): ?>
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-circle me-2"></i>
                            <?php echo $error; ?>
                        </div>
                    <?php endif; ?>
                    
                    <form method="POST" action="" class="needs-validation" novalidate>
                        <div class="mb-3">
                            <label for="email" class="form-label">البريد الإلكتروني</label>
                            <input type="email" class="form-control" id="email" name="email" required
                                   value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
                            <div class="form-text">
                                أدخل البريد الإلكتروني المسجل في حسابك وسنرسل لك رابطاً لإعادة تعيين كلمة المرور.
                            </div>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-paper-plane me-2"></i>
                            إرسال رابط إعادة التعيين
                        </button>
                        
                        <a href="login.php" class="btn btn-link">
                            <i class="fas fa-arrow-right me-2"></i>
                            العودة إلى تسجيل الدخول
                        </a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Form validation
(function() {
    'use strict';
    var forms = document.querySelectorAll('.needs-validation');
    Array.prototype.slice.call(forms).forEach(function(form) {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
    });
})();
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?> 