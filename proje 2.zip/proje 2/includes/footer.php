<?php
// Get categories for sidebar
$stmt = $pdo->query("SELECT * FROM categories WHERE parent_id IS NULL ORDER BY name");
$main_categories = $stmt->fetchAll();
?>

    </div><!-- End of container -->
    
    <footer class="bg-dark text-light py-4 mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-4">
                    <h5 class="mb-3">عن المنصة</h5>
                    <p>KREZMO منصة متكاملة للإعلانات المبوبة، تتيح للمستخدمين نشر وشراء وبيع مختلف السلع والخدمات.</p>
                </div>
                <div class="col-md-4 mb-4">
                    <h5 class="mb-3">روابط سريعة</h5>
                    <ul class="list-unstyled">
                        <li class="mb-2">
                            <a href="<?php echo SITE_URL; ?>/about.php" class="text-light text-decoration-none">
                                <i class="fas fa-info-circle me-2"></i>من نحن
                            </a>
                        </li>
                        <li class="mb-2">
                            <a href="<?php echo SITE_URL; ?>/contact.php" class="text-light text-decoration-none">
                                <i class="fas fa-envelope me-2"></i>اتصل بنا
                            </a>
                        </li>
                        <li class="mb-2">
                            <a href="<?php echo SITE_URL; ?>/privacy.php" class="text-light text-decoration-none">
                                <i class="fas fa-shield-alt me-2"></i>سياسة الخصوصية
                            </a>
                        </li>
                        <li class="mb-2">
                            <a href="<?php echo SITE_URL; ?>/terms.php" class="text-light text-decoration-none">
                                <i class="fas fa-file-contract me-2"></i>شروط الاستخدام
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="col-md-4 mb-4">
                    <h5 class="mb-3">تواصل معنا</h5>
                    <ul class="list-unstyled">
                        <li class="mb-2">
                            <i class="fas fa-envelope me-2"></i>
                            <?php echo ADMIN_EMAIL; ?>
                        </li>
                        <li class="mb-2">
                            <i class="fas fa-phone me-2"></i>
                            <?php echo ADMIN_PHONE; ?>
                        </li>
                    </ul>
                    <div class="social-links mt-3">
                        <a href="#" class="text-light me-3"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="text-light me-3"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="text-light me-3"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="text-light"><i class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>
            </div>
            <hr class="my-4">
            <div class="row">
                <div class="col-md-6 text-center text-md-start">
                    <p class="mb-0">&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?>. جميع الحقوق محفوظة.</p>
                </div>
                <div class="col-md-6 text-center text-md-end">
                    <p class="mb-0">تصميم وتطوير بواسطة <a href="#" class="text-light text-decoration-none">KREZMO Team</a></p>
                </div>
            </div>
        </div>
    </footer>

    <style>
        /* Change primary color to match header */
        .bg-primary {
            background-color: #1B5E20 !important;
        }

        .btn-primary {
            background-color: #1B5E20 !important;
            border-color: #1B5E20 !important;
        }

        .btn-primary:hover {
            background-color: #2E7D32 !important;
            border-color: #2E7D32 !important;
        }

        .text-primary {
            color: #1B5E20 !important;
        }

        .border-primary {
            border-color: #1B5E20 !important;
        }

        /* Footer Links Hover */
        .text-white-50:hover {
            color: white !important;
            text-decoration: none;
        }
    </style>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        // Add any custom JavaScript here
        $(document).ready(function() {
            // Initialize tooltips
            var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
            var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl)
            });
        });
    </script>

    <!-- Custom JavaScript -->
    <script src="<?php echo SITE_URL; ?>/assets/js/main.js"></script>
</body>
</html> 