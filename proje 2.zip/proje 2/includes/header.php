<?php
require_once __DIR__ . '/../config.php';

// Debug information
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Debug session
echo "<!-- Debug: Session contents: " . print_r($_SESSION, true) . " -->";

// Get current user data
$current_user = get_current_user();
$username = isset($current_user['username']) ? $current_user['username'] : '';

// Debug output
echo "<!-- Debug: User logged in: " . (is_logged_in() ? 'Yes' : 'No') . " -->";
echo "<!-- Debug: Current user: " . print_r($current_user, true) . " -->";
echo "<!-- Debug: Username: " . htmlspecialchars($username) . " -->";

// Get main categories with their subcategories
$stmt = $pdo->query("
    SELECT c.*, 
           (SELECT COUNT(*) FROM listings WHERE category_id = c.id AND status = 'active') as listing_count,
           GROUP_CONCAT(sc.id, ':', sc.name, ':', (SELECT COUNT(*) FROM listings WHERE category_id = sc.id AND status = 'active')) as subcategories
    FROM categories c
    LEFT JOIN categories sc ON sc.parent_id = c.id
    WHERE c.parent_id IS NULL
    GROUP BY c.id
    ORDER BY c.name
");
$categories = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .navbar {
            background-color: #1B5E20;
            padding: 1rem 0;
        }
        .navbar-brand {
            color: white !important;
            font-weight: bold;
            font-size: 1.5rem;
        }
        .search-form {
            flex-grow: 1;
            margin: 0 1rem;
        }
        .user-actions {
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        .btn-create-listing {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 0.5rem 1rem;
            border-radius: 5px;
        }
        .btn-create-listing:hover {
            background-color: #2E7D32;
            color: white;
        }
        .dropdown-menu {
            border: none;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            min-width: 200px;
        }
        .dropdown-item {
            padding: 0.75rem 1rem;
        }
        .dropdown-item i {
            margin-left: 0.5rem;
            width: 20px;
            text-align: center;
        }
        .btn-outline-light {
            border-width: 2px;
        }
        .btn-light {
            color: #1B5E20;
            font-weight: 500;
        }
        .categories-dropdown {
            min-width: 250px;
        }
        .subcategory-item {
            padding-right: 2rem !important;
        }
        .category-count {
            font-size: 0.8rem;
            color: #6c757d;
            margin-right: 0.5rem;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php"><?php echo SITE_NAME; ?></a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <form class="search-form" action="search.php" method="GET">
                    <input type="text" class="form-control" name="q" placeholder="ابحث عن إعلانات...">
                </form>
                
                <div class="user-actions">
                    <a href="add-listing.php" class="btn btn-create-listing">
                        <i class="fas fa-plus"></i> إنشاء إعلان
                    </a>
                    
                    <?php if (is_logged_in() && $current_user && !empty($username)): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" 
                               data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-user-circle me-1"></i>
                                <?php echo htmlspecialchars($username); ?>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                <li>
                                    <a class="dropdown-item" href="profile.php">
                                        <i class="fas fa-user me-2"></i>
                                        الملف الشخصي
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="my-listings.php">
                                        <i class="fas fa-list me-2"></i>
                                        إعلاناتي
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="favorites.php">
                                        <i class="fas fa-heart me-2"></i>
                                        المفضلة
                                    </a>
                                </li>
                                <li><hr class="dropdown-divider"></li>
                                <li>
                                    <a class="dropdown-item text-danger" href="logout.php">
                                        <i class="fas fa-sign-out-alt me-2"></i>
                                        تسجيل الخروج
                                    </a>
                                </li>
                            </ul>
                        </li>
                    <?php else: ?>
                        <?php
                        // Get current page URL for return after login/register
                        $current_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
                        $return_url = urlencode($current_url);
                        ?>
                        <a href="<?php echo SITE_URL; ?>/login.php?return=<?php echo $return_url; ?>" class="btn btn-outline-light">
                            <i class="fas fa-sign-in-alt"></i> تسجيل الدخول
                        </a>
                        <a href="<?php echo SITE_URL; ?>/register.php?return=<?php echo $return_url; ?>" class="btn btn-light">
                            <i class="fas fa-user-plus"></i> إنشاء حساب
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Debug: Log when DOM is loaded
        console.log('DOM loaded');
        
        // Initialize all dropdowns
        var dropdownElementList = [].slice.call(document.querySelectorAll('[data-bs-toggle="dropdown"]'));
        dropdownElementList.map(function(dropdownToggleEl) {
            return new bootstrap.Dropdown(dropdownToggleEl);
        });
        
        // Debug: Log dropdown elements
        console.log('Dropdown elements:', dropdownElementList);
    });
    </script>
</body>
</html> 