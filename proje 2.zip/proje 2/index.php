<?php
require_once __DIR__ . '/includes/header.php';

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Get main categories with their subcategories
$stmt = $pdo->query("
    SELECT c.*, 
           (SELECT COUNT(*) FROM listings WHERE category_id = c.id AND status = 'active') as listing_count
    FROM categories c
    WHERE c.parent_id IS NULL
    ORDER BY c.name
");
$categories = $stmt->fetchAll();

// Get subcategories for each main category
foreach ($categories as &$category) {
    $subcat_stmt = $pdo->prepare("
        SELECT sc.*, 
               (SELECT COUNT(*) FROM listings WHERE category_id = sc.id AND status = 'active') as listing_count
        FROM categories sc
        WHERE sc.parent_id = ?
        ORDER BY sc.name
    ");
    $subcat_stmt->execute([$category['id']]);
    $category['subcategories'] = $subcat_stmt->fetchAll();
}
unset($category);

// Get recent listings with user and category info
$query = "
    SELECT l.*, c.name as category_name, u.username,
           (SELECT image_url FROM listing_images WHERE listing_id = l.id LIMIT 1) as primary_image
    FROM listings l
    JOIN categories c ON l.category_id = c.id
    JOIN users u ON l.user_id = u.id
    WHERE l.status = 'active'
    ORDER BY l.created_at DESC
    LIMIT 12
";

// Debug: Print the query
echo "<!-- Debug: Query = " . htmlspecialchars($query) . " -->";

$stmt = $pdo->query($query);
$recent_listings = $stmt->fetchAll();

// Debug: Print the number of listings found
echo "<!-- Debug: Number of listings found = " . count($recent_listings) . " -->";

// Debug: Print each listing's details
foreach ($recent_listings as $listing) {
    echo "<!-- Debug: Listing ID = " . $listing['id'] . ", Title = " . htmlspecialchars($listing['title']) . ", Status = " . $listing['status'] . " -->";
}
?>

<style>
    .list-group-item {
        border: none;
        border-bottom: 1px solid rgba(0,0,0,.125);
    }
    .list-group-item:last-child {
        border-bottom: none;
    }
    .list-group-item a {
        color: #333;
        text-decoration: none;
        display: block;
        padding: 0.5rem 1rem;
    }
    .list-group-item a:hover {
        background-color: #f8f9fa;
    }
    .list-group-item .badge {
        font-size: 0.8rem;
    }
    .collapse .list-group-item {
        padding-right: 2rem;
        font-size: 0.9rem;
    }
    .collapse .list-group-item:hover {
        background-color: #f8f9fa;
    }
    .collapse .badge {
        font-size: 0.75rem;
    }
    [data-bs-toggle="collapse"] {
        position: relative;
    }
    [data-bs-toggle="collapse"]::after {
        content: '\f107';
        font-family: 'Font Awesome 5 Free';
        font-weight: 900;
        position: absolute;
        left: 1rem;
        top: 50%;
        transform: translateY(-50%);
        transition: transform 0.2s;
    }
    [data-bs-toggle="collapse"][aria-expanded="true"]::after {
        transform: translateY(-50%) rotate(180deg);
    }
    .category-item .list-group-item {
        border: none;
        padding: 0.75rem 1rem;
        transition: all 0.3s ease;
    }

    .category-item .list-group-item:hover {
        background-color: #f8f9fa;
    }

    .category-item .list-group-item[aria-expanded="true"] {
        background-color: #e9ecef;
    }

    .category-item .list-group-item[aria-expanded="true"]::after {
        content: '\f077';
        font-family: 'Font Awesome 5 Free';
        font-weight: 900;
        margin-right: 0.5rem;
        transition: transform 0.3s ease;
    }

    .category-item .list-group-item[aria-expanded="false"]::after {
        content: '\f078';
        font-family: 'Font Awesome 5 Free';
        font-weight: 900;
        margin-right: 0.5rem;
        transition: transform 0.3s ease;
    }

    .category-item .collapse {
        transition: all 0.3s ease;
    }

    .category-item .collapse.show {
        background-color: #f8f9fa;
    }

    .category-item .list-group-item .badge {
        float: left;
    }

    .category-item .list-group-item .badge.bg-secondary {
        background-color: #6c757d !important;
    }
</style>

<div class="container py-4">
    <div class="row">
        <!-- Main Content -->
        <div class="col-lg-9">
            <!-- Featured Listings -->
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">أحدث الإعلانات</h5>
                    <a href="listings.php" class="btn btn-sm btn-light">عرض الكل</a>
                </div>
                <div class="card-body">
                    <?php if (empty($recent_listings)): ?>
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle me-2"></i>
                            لا توجد إعلانات حالياً
                        </div>
                    <?php else: ?>
                        <div class="row g-4">
                            <?php foreach ($recent_listings as $listing): ?>
                                <div class="col-md-4">
                                    <div class="card h-100 shadow-sm">
                                        <img src="<?php echo $listing['primary_image'] ?: 'assets/images/no-image.jpg'; ?>" 
                                             class="card-img-top" alt="<?php echo htmlspecialchars($listing['title']); ?>"
                                             style="height: 200px; object-fit: cover;">
                                        <div class="card-body">
                                            <span class="badge bg-primary mb-2"><?php echo htmlspecialchars($listing['category_name']); ?></span>
                                            <h5 class="card-title">
                                                <a href="listing.php?id=<?php echo $listing['id']; ?>" class="text-decoration-none text-dark">
                                                    <?php echo htmlspecialchars($listing['title']); ?>
                                                </a>
                                            </h5>
                                            <p class="card-text text-primary mb-2"><?php echo number_format($listing['price']); ?> ل.س</p>
                                            <p class="card-text text-muted small">
                                                <i class="fas fa-user me-1"></i> <?php echo htmlspecialchars($listing['username']); ?><br>
                                                <i class="fas fa-clock me-1"></i> <?php echo date('Y/m/d', strtotime($listing['created_at'])); ?>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Sidebar -->
        <div class="col-lg-3">
            <!-- Categories -->
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">التصنيفات</h5>
                </div>
                <div class="card-body p-0">
                    <div class="list-group list-group-flush">
                        <?php foreach ($categories as $category): ?>
                            <div class="category-item">
                                <a href="#" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center" 
                                   data-bs-toggle="collapse" 
                                   data-bs-target="#subcat-<?php echo $category['id']; ?>"
                                   aria-expanded="false"
                                   aria-controls="subcat-<?php echo $category['id']; ?>">
                                    <?php echo htmlspecialchars($category['name']); ?>
                                    <span class="badge bg-primary rounded-pill"><?php echo $category['listing_count']; ?></span>
                                </a>
                                <?php if (!empty($category['subcategories'])): ?>
                                    <div class="collapse" id="subcat-<?php echo $category['id']; ?>">
                                        <div class="list-group list-group-flush">
                                            <?php foreach ($category['subcategories'] as $subcategory): ?>
                                                <a href="category.php?id=<?php echo $subcategory['id']; ?>" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                                                    <?php echo htmlspecialchars($subcategory['name']); ?>
                                                    <span class="badge bg-secondary rounded-pill"><?php echo $subcategory['listing_count']; ?></span>
                                                </a>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <!-- Create Listing Button -->
            <div class="d-grid">
                <a href="create-listing.php" class="btn btn-primary btn-lg">
                    <i class="fas fa-plus-circle me-2"></i>
                    إنشاء إعلان جديد
                </a>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Get all category links
    const categoryLinks = document.querySelectorAll('[data-bs-toggle="collapse"]');
    
    categoryLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Get the target collapse element
            const targetId = this.getAttribute('data-bs-target');
            const targetElement = document.querySelector(targetId);
            
            // Toggle the collapse
            if (targetElement.classList.contains('show')) {
                targetElement.classList.remove('show');
                this.setAttribute('aria-expanded', 'false');
            } else {
                targetElement.classList.add('show');
                this.setAttribute('aria-expanded', 'true');
            }
        });
    });
});
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?> 