<?php
require_once __DIR__ . '/includes/header.php';

$listing_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Get listing details with user and category info
$stmt = $pdo->prepare("
    SELECT l.*, c.name as category_name, u.username, u.email as user_email, u.phone,
           (SELECT COUNT(*) FROM listing_images WHERE listing_id = l.id) as image_count
    FROM listings l
    JOIN categories c ON l.category_id = c.id
    JOIN users u ON l.user_id = u.id
    WHERE l.id = ? AND l.status = 'active'
");
$stmt->execute([$listing_id]);
$listing = $stmt->fetch();

if (!$listing) {
    redirect('index.php');
}

// Get listing images
$stmt = $pdo->prepare("SELECT * FROM listing_images WHERE listing_id = ? ORDER BY is_primary DESC");
$stmt->execute([$listing_id]);
$images = $stmt->fetchAll();

// Get listing video
$stmt = $pdo->prepare("SELECT video_url FROM listing_videos WHERE listing_id = ? LIMIT 1");
$stmt->execute([$listing_id]);
$video = $stmt->fetch();

// Handle report submission
$report_success = false;
$report_error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['report'])) {
    $report_reason = clean($_POST['report_reason']);
    $report_details = clean($_POST['report_details']);
    
    if (empty($report_reason)) {
        $report_error = 'يرجى اختيار سبب الإبلاغ';
    } else {
        // Send report email
        $to = ADMIN_EMAIL;
        $subject = 'تقرير عن إعلان - ' . SITE_NAME;
        $message = "
            <html dir='rtl'>
            <head>
                <title>تقرير عن إعلان</title>
            </head>
            <body>
                <h2>تقرير جديد عن إعلان</h2>
                <p><strong>معرف الإعلان:</strong> {$listing_id}</p>
                <p><strong>عنوان الإعلان:</strong> {$listing['title']}</p>
                <p><strong>صاحب الإعلان:</strong> {$listing['username']}</p>
                <p><strong>سبب الإبلاغ:</strong> {$report_reason}</p>
                <p><strong>تفاصيل الإبلاغ:</strong> {$report_details}</p>
                <br>
                <p>يمكنك مراجعة الإعلان من خلال الرابط التالي:</p>
                <p><a href='" . SITE_URL . "/listing.php?id={$listing_id}'>عرض الإعلان</a></p>
            </body>
            </html>
        ";
        
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "From: " . SITE_NAME . " <" . ADMIN_EMAIL . ">" . "\r\n";
        
        if (mail($to, $subject, $message, $headers)) {
            $report_success = true;
        } else {
            $report_error = 'حدث خطأ أثناء إرسال التقرير. يرجى المحاولة لاحقاً.';
        }
    }
}
?>

<div class="container py-4">
    <div class="row">
        <!-- Main Content -->
        <div class="col-lg-8">
            <!-- Listing Images -->
            <div class="card shadow-sm mb-4">
                <div class="card-body p-0">
                    <?php if (!empty($images)): ?>
                        <div id="listingCarousel" class="carousel slide" data-bs-ride="carousel">
                            <div class="carousel-inner">
                                <?php foreach ($images as $index => $image): ?>
                                    <div class="carousel-item <?php echo $index === 0 ? 'active' : ''; ?>">
                                        <img src="<?php echo htmlspecialchars($image['image_url']); ?>" 
                                             class="d-block w-100" alt="<?php echo htmlspecialchars($listing['title']); ?>"
                                             style="height: 400px; object-fit: cover;">
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <?php if (count($images) > 1): ?>
                                <button class="carousel-control-prev" type="button" data-bs-target="#listingCarousel" data-bs-slide="prev">
                                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                    <span class="visually-hidden">السابق</span>
                                </button>
                                <button class="carousel-control-next" type="button" data-bs-target="#listingCarousel" data-bs-slide="next">
                                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                    <span class="visually-hidden">التالي</span>
                                </button>
                            <?php endif; ?>
                        </div>
                        
                        <!-- Thumbnails -->
                        <?php if (count($images) > 1): ?>
                            <div class="row g-2 p-2">
                                <?php foreach ($images as $index => $image): ?>
                                    <div class="col-3">
                                        <img src="<?php echo htmlspecialchars($image['image_url']); ?>" 
                                             class="img-thumbnail" alt=""
                                             style="height: 80px; object-fit: cover; cursor: pointer;"
                                             onclick="$('#listingCarousel').carousel(<?php echo $index; ?>)">
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    <?php else: ?>
                        <img src="assets/images/no-image.jpg" class="img-fluid" alt="No Image"
                             style="height: 400px; object-fit: cover;">
                    <?php endif; ?>
                </div>
            </div>

            <!-- Video Section -->
            <?php if ($video && $video['video_url']): ?>
                <div class="card shadow-sm mb-4">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">فيديو الإعلان</h5>
                    </div>
                    <div class="card-body">
                        <div class="ratio ratio-16x9">
                            <iframe src="<?php echo htmlspecialchars($video['video_url']); ?>" 
                                    allowfullscreen></iframe>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Listing Details -->
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">تفاصيل الإعلان</h5>
                </div>
                <div class="card-body">
                    <h4 class="card-title mb-3"><?php echo htmlspecialchars($listing['title']); ?></h4>
                    
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <p class="mb-2">
                                <i class="fas fa-tag text-primary me-2"></i>
                                <strong>التصنيف:</strong> <?php echo htmlspecialchars($listing['category_name']); ?>
                            </p>
                            <p class="mb-2">
                                <i class="fas fa-map-marker-alt text-primary me-2"></i>
                                <strong>الموقع:</strong> <?php echo htmlspecialchars($listing['location']); ?>
                            </p>
                            <p class="mb-2">
                                <i class="fas fa-calendar text-primary me-2"></i>
                                <strong>تاريخ النشر:</strong> <?php echo date('Y/m/d', strtotime($listing['created_at'])); ?>
                            </p>
                        </div>
                        <div class="col-md-6">
                            <p class="mb-2">
                                <i class="fas fa-user text-primary me-2"></i>
                                <strong>المعلن:</strong> <?php echo htmlspecialchars($listing['username']); ?>
                            </p>
                            <p class="mb-2">
                                <i class="fas fa-eye text-primary me-2"></i>
                                <strong>المشاهدات:</strong> <?php echo number_format($listing['views']); ?>
                            </p>
                        </div>
                    </div>

                    <div class="mb-4">
                        <h5 class="mb-3">الوصف</h5>
                        <p class="card-text"><?php echo nl2br(htmlspecialchars($listing['description'])); ?></p>
                    </div>

                    <?php if (!empty($listing['features'])): ?>
                        <div class="mb-4">
                            <h5 class="mb-3">المميزات</h5>
                            <ul class="list-unstyled">
                                <?php foreach (explode("\n", $listing['features']) as $feature): ?>
                                    <?php if (trim($feature)): ?>
                                        <li><i class="fas fa-check text-success me-2"></i><?php echo htmlspecialchars(trim($feature)); ?></li>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Sidebar -->
        <div class="col-lg-4">
            <!-- Price Card -->
            <div class="card shadow-sm mb-4">
                <div class="card-body text-center">
                    <h3 class="text-primary mb-3"><?php echo number_format($listing['price']); ?> ل.س</h3>
                    <?php if (isLoggedIn() && $_SESSION['user']['id'] !== $listing['user_id']): ?>
                        <?php if (!empty($listing['phone'])): ?>
                            <a href="https://wa.me/<?php echo preg_replace('/[^0-9]/', '', $listing['phone']); ?>?text=<?php echo urlencode('مرحباً، أنا مهتم بإعلانك: ' . $listing['title']); ?>" 
                               class="btn btn-success btn-lg w-100 mb-2" target="_blank">
                                <i class="fab fa-whatsapp me-2"></i>
                                تواصل عبر واتساب
                            </a>
                        <?php endif; ?>
                        <button type="button" class="btn btn-primary btn-lg w-100 mb-2" data-bs-toggle="modal" data-bs-target="#contactModal">
                            <i class="fas fa-envelope me-2"></i>
                            تواصل مع المعلن
                        </button>
                    <?php endif; ?>
                    <button type="button" class="btn btn-outline-danger w-100" data-bs-toggle="modal" data-bs-target="#reportModal">
                        <i class="fas fa-flag me-2"></i>
                        الإبلاغ عن الإعلان
                    </button>
                </div>
            </div>

            <!-- Similar Listings -->
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">إعلانات مشابهة</h5>
                </div>
                <div class="card-body">
                    <?php
                    $stmt = $pdo->prepare("
                        SELECT l.*, c.name as category_name,
                               (SELECT image_url FROM listing_images WHERE listing_id = l.id LIMIT 1) as primary_image
                        FROM listings l
                        JOIN categories c ON l.category_id = c.id
                        WHERE l.category_id = ? AND l.id != ? AND l.status = 'active'
                        ORDER BY l.created_at DESC
                        LIMIT 3
                    ");
                    $stmt->execute([$listing['category_id'], $listing_id]);
                    $similar_listings = $stmt->fetchAll();
                    
                    if ($similar_listings):
                        foreach ($similar_listings as $similar):
                    ?>
                        <div class="d-flex mb-3">
                            <img src="<?php echo $similar['primary_image'] ?: 'assets/images/no-image.jpg'; ?>" 
                                 class="rounded" alt=""
                                 style="width: 80px; height: 80px; object-fit: cover;">
                            <div class="ms-3">
                                <h6 class="mb-1">
                                    <a href="listing.php?id=<?php echo $similar['id']; ?>" class="text-decoration-none text-dark">
                                        <?php echo htmlspecialchars($similar['title']); ?>
                                    </a>
                                </h6>
                                <p class="text-primary mb-0"><?php echo number_format($similar['price']); ?> ل.س</p>
                            </div>
                        </div>
                    <?php 
                        endforeach;
                    else:
                    ?>
                        <p class="text-muted mb-0">لا توجد إعلانات مشابهة</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Contact Modal -->
<?php if (isLoggedIn() && $_SESSION['user']['id'] !== $listing['user_id']): ?>
<div class="modal fade" id="contactModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">تواصل مع المعلن</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="contactForm" method="POST" action="send-message.php">
                    <input type="hidden" name="listing_id" value="<?php echo $listing_id; ?>">
                    <input type="hidden" name="recipient_id" value="<?php echo $listing['user_id']; ?>">
                    
                    <div class="mb-3">
                        <label for="message" class="form-label">رسالتك</label>
                        <textarea class="form-control" id="message" name="message" rows="4" required></textarea>
                    </div>
                    
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-paper-plane me-2"></i>
                        إرسال الرسالة
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Report Modal -->
<div class="modal fade" id="reportModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">الإبلاغ عن الإعلان</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <?php if ($report_success): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle me-2"></i>
                        تم إرسال تقريرك بنجاح. سنقوم بمراجعته في أقرب وقت ممكن.
                    </div>
                <?php else: ?>
                    <?php if ($report_error): ?>
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-circle me-2"></i>
                            <?php echo $report_error; ?>
                        </div>
                    <?php endif; ?>
                    
                    <form method="POST">
                        <input type="hidden" name="report" value="1">
                        
                        <div class="mb-3">
                            <label for="report_reason" class="form-label">سبب الإبلاغ</label>
                            <select class="form-select" id="report_reason" name="report_reason" required>
                                <option value="">اختر السبب</option>
                                <option value="محتوى غير لائق">محتوى غير لائق</option>
                                <option value="إعلان مزيف">إعلان مزيف</option>
                                <option value="سعر غير واقعي">سعر غير واقعي</option>
                                <option value="معلومات غير صحيحة">معلومات غير صحيحة</option>
                                <option value="إعلان مكرر">إعلان مكرر</option>
                                <option value="أخرى">أخرى</option>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label for="report_details" class="form-label">تفاصيل الإبلاغ</label>
                            <textarea class="form-control" id="report_details" name="report_details" rows="4" required></textarea>
                        </div>
                        
                        <button type="submit" class="btn btn-danger w-100">
                            <i class="fas fa-flag me-2"></i>
                            إرسال التقرير
                        </button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
// Initialize tooltips
var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
    return new bootstrap.Tooltip(tooltipTriggerEl)
});

// Form validation
(function() {
    'use strict';
    var forms = document.querySelectorAll('.needs-validation');
    Array.prototype.slice.call(forms).forEach(function(form) {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
    });
})();
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?> 