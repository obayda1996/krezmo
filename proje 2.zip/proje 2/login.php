<?php
require_once 'config.php';

// Get return URL from parameter
$return_url = isset($_GET['return']) ? $_GET['return'] : 'index.php';

// If user is already logged in, redirect to return URL
if (is_logged_in()) {
    redirect($return_url);
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = clean($_POST['username']);
    $password = $_POST['password'];
    
    if (empty($username) || empty($password)) {
        $error = 'يرجى إدخال اسم المستخدم وكلمة المرور';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch();
        
        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            redirect($return_url);
        } else {
            $error = 'اسم المستخدم أو كلمة المرور غير صحيحة';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تسجيل الدخول - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .login-container {
            max-width: 400px;
            margin: 50px auto;
            padding: 20px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .login-header {
            text-align: center;
            margin-bottom: 30px;
        }
        .login-header h1 {
            color: #1B5E20;
            font-size: 24px;
            margin-bottom: 10px;
        }
        .form-control {
            border-radius: 5px;
            padding: 10px;
        }
        .btn-login {
            background-color: #1B5E20;
            color: white;
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 5px;
            margin-top: 20px;
        }
        .btn-login:hover {
            background-color: #2E7D32;
            color: white;
        }
        .register-link {
            text-align: center;
            margin-top: 20px;
        }
        .register-link a {
            color: #1B5E20;
            text-decoration: none;
        }
        .register-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <?php require_once 'includes/header.php'; ?>
    
    <div class="container">
        <div class="login-container">
            <div class="login-header">
                <h1>تسجيل الدخول</h1>
                <p>مرحباً بعودتك! قم بتسجيل الدخول للوصول إلى حسابك</p>
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <form method="POST" action="login.php<?php echo isset($_GET['return']) ? '?return=' . htmlspecialchars($_GET['return']) : ''; ?>">
                <div class="mb-3">
                    <label for="username" class="form-label">اسم المستخدم</label>
                    <input type="text" class="form-control" id="username" name="username" required>
                </div>
                
                <div class="mb-3">
                    <label for="password" class="form-label">كلمة المرور</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>
                
                <button type="submit" class="btn btn-login">تسجيل الدخول</button>
            </form>
            
            <div class="register-link">
                ليس لديك حساب؟ <a href="register.php<?php echo isset($_GET['return']) ? '?return=' . htmlspecialchars($_GET['return']) : ''; ?>">إنشاء حساب جديد</a>
            </div>
        </div>
    </div>
    
    <?php require_once 'includes/footer.php'; ?>
</body>
</html> 