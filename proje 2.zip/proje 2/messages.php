<?php
require_once 'includes/header.php';

// Check if user is logged in
if(!isset($_SESSION['user_id'])) {
    redirect('login.php');
}

// Get conversations
$stmt = $pdo->prepare("
    SELECT DISTINCT 
        CASE 
            WHEN m.sender_id = ? THEN m.receiver_id
            ELSE m.sender_id
        END as other_user_id,
        u.username as other_username,
        u.profile_image as other_profile_image,
        (
            SELECT message 
            FROM messages 
            WHERE (sender_id = ? AND receiver_id = other_user_id)
               OR (sender_id = other_user_id AND receiver_id = ?)
            ORDER BY created_at DESC 
            LIMIT 1
        ) as last_message,
        (
            SELECT created_at 
            FROM messages 
            WHERE (sender_id = ? AND receiver_id = other_user_id)
               OR (sender_id = other_user_id AND receiver_id = ?)
            ORDER BY created_at DESC 
            LIMIT 1
        ) as last_message_time,
        (
            SELECT COUNT(*) 
            FROM messages 
            WHERE sender_id = other_user_id 
            AND receiver_id = ? 
            AND is_read = 0
        ) as unread_count
    FROM messages m
    JOIN users u ON (
        CASE 
            WHEN m.sender_id = ? THEN m.receiver_id
            ELSE m.sender_id
        END = u.id
    )
    WHERE m.sender_id = ? OR m.receiver_id = ?
    ORDER BY last_message_time DESC
");
$stmt->execute([
    $_SESSION['user_id'], $_SESSION['user_id'], $_SESSION['user_id'],
    $_SESSION['user_id'], $_SESSION['user_id'], $_SESSION['user_id'],
    $_SESSION['user_id'], $_SESSION['user_id'], $_SESSION['user_id']
]);
$conversations = $stmt->fetchAll();

// Get messages for specific conversation if user_id is provided
$selected_user = null;
$messages = [];
if(isset($_GET['user_id'])) {
    $other_user_id = (int)$_GET['user_id'];
    
    // Get other user's information
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$other_user_id]);
    $selected_user = $stmt->fetch();
    
    if($selected_user) {
        // Get messages
        $stmt = $pdo->prepare("
            SELECT m.*, u.username, u.profile_image
            FROM messages m
            JOIN users u ON m.sender_id = u.id
            WHERE (m.sender_id = ? AND m.receiver_id = ?)
               OR (m.sender_id = ? AND m.receiver_id = ?)
            ORDER BY m.created_at ASC
        ");
        $stmt->execute([
            $_SESSION['user_id'], $other_user_id,
            $other_user_id, $_SESSION['user_id']
        ]);
        $messages = $stmt->fetchAll();
        
        // Mark messages as read
        $stmt = $pdo->prepare("
            UPDATE messages 
            SET is_read = 1 
            WHERE sender_id = ? AND receiver_id = ? AND is_read = 0
        ");
        $stmt->execute([$other_user_id, $_SESSION['user_id']]);
    }
}

// Handle new message
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['message']) && isset($_POST['receiver_id'])) {
    $message = clean($_POST['message']);
    $receiver_id = (int)$_POST['receiver_id'];
    
    if(!empty($message)) {
        $stmt = $pdo->prepare("
            INSERT INTO messages (sender_id, receiver_id, message, created_at) 
            VALUES (?, ?, ?, NOW())
        ");
        $stmt->execute([$_SESSION['user_id'], $receiver_id, $message]);
        
        // Redirect to refresh the page
        redirect("messages.php?user_id=" . $receiver_id);
    }
}
?>

<div class="container py-5">
    <div class="row">
        <!-- Conversations List -->
        <div class="col-md-4">
            <div class="card shadow">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">المحادثات</h5>
                </div>
                <div class="list-group list-group-flush">
                    <?php if(empty($conversations)): ?>
                        <div class="text-center py-5">
                            <i class="fas fa-comments fa-3x text-muted mb-3"></i>
                            <p class="text-muted">لا توجد محادثات</p>
                        </div>
                    <?php else: ?>
                        <?php foreach($conversations as $conv): ?>
                            <a href="?user_id=<?php echo $conv['other_user_id']; ?>" 
                               class="list-group-item list-group-item-action <?php echo isset($_GET['user_id']) && $_GET['user_id'] == $conv['other_user_id'] ? 'active' : ''; ?>">
                                <div class="d-flex align-items-center">
                                    <img src="<?php echo !empty($conv['other_profile_image']) ? $conv['other_profile_image'] : 'assets/images/default-avatar.png'; ?>" 
                                         class="rounded-circle me-3" width="50" height="50" style="object-fit: cover;">
                                    <div class="flex-grow-1">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <h6 class="mb-0"><?php echo $conv['other_username']; ?></h6>
                                            <?php if($conv['unread_count'] > 0): ?>
                                                <span class="badge bg-danger rounded-pill"><?php echo $conv['unread_count']; ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <p class="mb-0 text-muted small"><?php echo $conv['last_message']; ?></p>
                                        <small class="text-muted"><?php echo date('Y/m/d H:i', strtotime($conv['last_message_time'])); ?></small>
                                    </div>
                                </div>
                            </a>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Messages -->
        <div class="col-md-8">
            <?php if($selected_user): ?>
                <div class="card shadow">
                    <div class="card-header bg-primary text-white">
                        <div class="d-flex align-items-center">
                            <img src="<?php echo !empty($selected_user['profile_image']) ? $selected_user['profile_image'] : 'assets/images/default-avatar.png'; ?>" 
                                 class="rounded-circle me-3" width="40" height="40" style="object-fit: cover;">
                            <h5 class="mb-0"><?php echo $selected_user['username']; ?></h5>
                        </div>
                    </div>
                    
                    <div class="card-body" style="height: 400px; overflow-y: auto;">
                        <?php if(empty($messages)): ?>
                            <div class="text-center py-5">
                                <i class="fas fa-comment fa-3x text-muted mb-3"></i>
                                <p class="text-muted">لا توجد رسائل</p>
                            </div>
                        <?php else: ?>
                            <?php foreach($messages as $message): ?>
                                <div class="d-flex mb-3 <?php echo $message['sender_id'] == $_SESSION['user_id'] ? 'justify-content-end' : ''; ?>">
                                    <div class="message <?php echo $message['sender_id'] == $_SESSION['user_id'] ? 'bg-primary text-white' : 'bg-light'; ?>" 
                                         style="max-width: 70%; padding: 10px 15px; border-radius: 15px;">
                                        <p class="mb-0"><?php echo $message['message']; ?></p>
                                        <small class="<?php echo $message['sender_id'] == $_SESSION['user_id'] ? 'text-white-50' : 'text-muted'; ?>">
                                            <?php echo date('H:i', strtotime($message['created_at'])); ?>
                                        </small>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                    
                    <div class="card-footer">
                        <form method="POST" action="" class="d-flex">
                            <input type="hidden" name="receiver_id" value="<?php echo $selected_user['id']; ?>">
                            <input type="text" name="message" class="form-control me-2" placeholder="اكتب رسالتك هنا..." required>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-paper-plane"></i>
                            </button>
                        </form>
                    </div>
                </div>
            <?php else: ?>
                <div class="card shadow">
                    <div class="card-body text-center py-5">
                        <i class="fas fa-comments fa-3x text-muted mb-3"></i>
                        <p class="text-muted">اختر محادثة لعرض الرسائل</p>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?> 