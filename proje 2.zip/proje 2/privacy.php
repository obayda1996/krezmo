<?php
require_once __DIR__ . '/includes/header.php';
?>

<div class="container py-5">
    <div class="row">
        <div class="col-lg-8 mx-auto">
            <div class="card shadow">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0">سياسة الخصوصية</h4>
                </div>
                <div class="card-body">
                    <div class="mb-4">
                        <h5 class="text-primary">مقدمة</h5>
                        <p>نحن في KREZMO نلتزم بحماية خصوصية مستخدمينا. توضح سياسة الخصوصية هذه كيفية جمع واستخدام وحماية المعلومات الشخصية التي تقدمها لنا.</p>
                    </div>

                    <div class="mb-4">
                        <h5 class="text-primary">المعلومات التي نجمعها</h5>
                        <ul class="list-unstyled">
                            <li class="mb-2">
                                <i class="fas fa-check-circle text-success me-2"></i>
                                <strong>المعلومات الشخصية:</strong> الاسم، البريد الإلكتروني، رقم الهاتف
                            </li>
                            <li class="mb-2">
                                <i class="fas fa-check-circle text-success me-2"></i>
                                <strong>معلومات الحساب:</strong> اسم المستخدم، كلمة المرور، تاريخ التسجيل
                            </li>
                            <li class="mb-2">
                                <i class="fas fa-check-circle text-success me-2"></i>
                                <strong>معلومات الإعلانات:</strong> الصور، الوصف، السعر، الموقع
                            </li>
                        </ul>
                    </div>

                    <div class="mb-4">
                        <h5 class="text-primary">كيف نستخدم معلوماتك</h5>
                        <ul class="list-unstyled">
                            <li class="mb-2">
                                <i class="fas fa-check-circle text-success me-2"></i>
                                توفير وإدارة خدمات المنصة
                            </li>
                            <li class="mb-2">
                                <i class="fas fa-check-circle text-success me-2"></i>
                                التواصل معك بخصوص حسابك وإعلاناتك
                            </li>
                            <li class="mb-2">
                                <i class="fas fa-check-circle text-success me-2"></i>
                                تحسين خدماتنا وتجربة المستخدم
                            </li>
                            <li class="mb-2">
                                <i class="fas fa-check-circle text-success me-2"></i>
                                حماية المنصة ومستخدميها
                            </li>
                        </ul>
                    </div>

                    <div class="mb-4">
                        <h5 class="text-primary">حماية المعلومات</h5>
                        <p>نحن نستخدم تقنيات تشفير متقدمة لحماية معلوماتك الشخصية. كما نقوم بتحديث أنظمتنا الأمنية بشكل دوري لضمان أمان بياناتك.</p>
                    </div>

                    <div class="mb-4">
                        <h5 class="text-primary">مشاركة المعلومات</h5>
                        <p>لا نقوم ببيع أو تأجير أو مشاركة معلوماتك الشخصية مع أي طرف ثالث إلا في الحالات التالية:</p>
                        <ul class="list-unstyled">
                            <li class="mb-2">
                                <i class="fas fa-check-circle text-success me-2"></i>
                                عند الحصول على موافقتك
                            </li>
                            <li class="mb-2">
                                <i class="fas fa-check-circle text-success me-2"></i>
                                عند الالتزام بطلب قانوني
                            </li>
                            <li class="mb-2">
                                <i class="fas fa-check-circle text-success me-2"></i>
                                لحماية حقوقنا ومستخدمينا
                            </li>
                        </ul>
                    </div>

                    <div class="mb-4">
                        <h5 class="text-primary">ملفات تعريف الارتباط</h5>
                        <p>نستخدم ملفات تعريف الارتباط لتحسين تجربة التصفح وتقديم خدمات مخصصة. يمكنك التحكم في إعدادات ملفات تعريف الارتباط من خلال متصفحك.</p>
                    </div>

                    <div class="mb-4">
                        <h5 class="text-primary">حقوقك</h5>
                        <p>لديك الحق في:</p>
                        <ul class="list-unstyled">
                            <li class="mb-2">
                                <i class="fas fa-check-circle text-success me-2"></i>
                                الوصول إلى معلوماتك الشخصية
                            </li>
                            <li class="mb-2">
                                <i class="fas fa-check-circle text-success me-2"></i>
                                تصحيح أو تحديث معلوماتك
                            </li>
                            <li class="mb-2">
                                <i class="fas fa-check-circle text-success me-2"></i>
                                طلب حذف حسابك
                            </li>
                            <li class="mb-2">
                                <i class="fas fa-check-circle text-success me-2"></i>
                                الاعتراض على معالجة بياناتك
                            </li>
                        </ul>
                    </div>

                    <div class="mb-4">
                        <h5 class="text-primary">التغييرات على سياسة الخصوصية</h5>
                        <p>قد نقوم بتحديث سياسة الخصوصية من وقت لآخر. سيتم إخطارك بأي تغييرات جوهرية من خلال البريد الإلكتروني أو إشعار على المنصة.</p>
                    </div>

                    <div class="mb-4">
                        <h5 class="text-primary">اتصل بنا</h5>
                        <p>إذا كان لديك أي أسئلة حول سياسة الخصوصية، يرجى التواصل معنا عبر:</p>
                        <p class="mb-0">
                            <i class="fas fa-envelope text-primary me-2"></i>
                            <?php echo ADMIN_EMAIL; ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?> 