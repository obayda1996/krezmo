<?php
require_once 'includes/header.php';

// Check if user is logged in
if(!isset($_SESSION['user_id'])) {
    redirect('login.php');
}

// Get user information
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

// If user not found, redirect to login
if(!$user) {
    session_destroy();
    redirect('login.php');
}

// Get user's listings
$stmt = $pdo->prepare("
    SELECT l.*, c.name as category_name, 
           (SELECT image_url FROM listing_images WHERE listing_id = l.id AND is_primary = 1 LIMIT 1) as image_url
    FROM listings l
    JOIN categories c ON l.category_id = c.id
    WHERE l.user_id = ?
    ORDER BY l.created_at DESC
");
$stmt->execute([$_SESSION['user_id']]);
$listings = $stmt->fetchAll();

// Handle profile update
$error = '';
$success = '';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $full_name = clean($_POST['full_name']);
    $phone = clean($_POST['phone']);
    $city = clean($_POST['city']);
    
    // Handle profile image upload
    if(!empty($_FILES['profile_image']['name'])) {
        $upload_dir = 'uploads/profiles/';
        if(!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        $file_name = $_FILES['profile_image']['name'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        $new_file_name = uniqid() . '.' . $file_ext;
        $file_path = $upload_dir . $new_file_name;
        
        if(move_uploaded_file($_FILES['profile_image']['tmp_name'], $file_path)) {
            $stmt = $pdo->prepare("UPDATE users SET profile_image = ? WHERE id = ?");
            $stmt->execute([$file_path, $_SESSION['user_id']]);
        }
    }
    
    // Update user information
    $stmt = $pdo->prepare("UPDATE users SET full_name = ?, phone = ?, city = ? WHERE id = ?");
    if($stmt->execute([$full_name, $phone, $city, $_SESSION['user_id']])) {
        $success = 'تم تحديث الملف الشخصي بنجاح';
        // Refresh user data
        $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch();
    } else {
        $error = 'حدث خطأ أثناء تحديث الملف الشخصي';
    }
}
?>

<div class="container py-5">
    <div class="row">
        <!-- Profile Information -->
        <div class="col-md-4">
            <div class="card shadow mb-4">
                <div class="card-body text-center">
                    <img src="<?php echo !empty($user['profile_image']) ? $user['profile_image'] : 'assets/images/default-avatar.png'; ?>" 
                         class="rounded-circle mb-3" width="150" height="150" style="object-fit: cover;">
                    
                    <h4><?php echo htmlspecialchars($user['username']); ?></h4>
                    <p class="text-muted"><?php echo htmlspecialchars($user['email']); ?></p>
                    
                    <hr>
                    
                    <form method="POST" action="" enctype="multipart/form-data">
                        <?php if($error): ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>
                        
                        <?php if($success): ?>
                            <div class="alert alert-success"><?php echo $success; ?></div>
                        <?php endif; ?>
                        
                        <div class="mb-3">
                            <label for="profile_image" class="form-label">تغيير الصورة الشخصية</label>
                            <input type="file" class="form-control" id="profile_image" name="profile_image" accept="image/*">
                        </div>
                        
                        <div class="mb-3">
                            <label for="full_name" class="form-label">الاسم الكامل</label>
                            <input type="text" class="form-control" id="full_name" name="full_name" 
                                   value="<?php echo htmlspecialchars($user['full_name'] ?? ''); ?>">
                        </div>
                        
                        <div class="mb-3">
                            <label for="phone" class="form-label">رقم الهاتف</label>
                            <input type="tel" class="form-control" id="phone" name="phone" 
                                   value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
                        </div>
                        
                        <div class="mb-3">
                            <label for="city" class="form-label">المدينة</label>
                            <select class="form-select" id="city" name="city">
                                <option value="">اختر المدينة</option>
                                <?php
                                $cities = [
                                    'دمشق', 'حلب', 'حمص', 'حماة', 'اللاذقية', 'طرطوس',
                                    'دير الزور', 'الحسكة', 'الرقة', 'السويداء', 'درعا', 'إدلب'
                                ];
                                foreach($cities as $city_name) {
                                    $selected = ($user['city'] ?? '') === $city_name ? 'selected' : '';
                                    echo "<option value=\"$city_name\" $selected>$city_name</option>";
                                }
                                ?>
                            </select>
                        </div>
                        
                        <button type="submit" class="btn btn-primary w-100">حفظ التغييرات</button>
                    </form>
                </div>
            </div>
        </div>
        
        <!-- User's Listings -->
        <div class="col-md-8">
            <div class="card shadow">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h4 class="mb-0">إعلاناتي</h4>
                        <a href="add-listing.php" class="btn btn-primary">
                            <i class="fas fa-plus"></i> إضافة إعلان جديد
                        </a>
                    </div>
                    
                    <?php if(empty($listings)): ?>
                        <div class="text-center py-5">
                            <i class="fas fa-box-open fa-3x text-muted mb-3"></i>
                            <p class="text-muted">لا توجد إعلانات حتى الآن</p>
                            <a href="add-listing.php" class="btn btn-primary">إضافة إعلان جديد</a>
                        </div>
                    <?php else: ?>
                        <div class="row">
                            <?php foreach($listings as $listing): ?>
                                <div class="col-md-6 mb-4">
                                    <div class="card h-100">
                                        <img src="<?php echo $listing['image_url'] ?: 'assets/images/no-image.jpg'; ?>" 
                                             class="card-img-top" alt="<?php echo htmlspecialchars($listing['title']); ?>"
                                             style="height: 200px; object-fit: cover;">
                                        <div class="card-body">
                                            <h5 class="card-title"><?php echo htmlspecialchars($listing['title']); ?></h5>
                                            <p class="card-text text-primary mb-2"><?php echo number_format($listing['price']); ?> ل.س</p>
                                            <p class="card-text text-muted small mb-2">
                                                <i class="fas fa-tag me-1"></i> <?php echo htmlspecialchars($listing['category_name']); ?>
                                            </p>
                                            <p class="card-text text-muted small mb-3">
                                                <i class="fas fa-calendar me-1"></i> <?php echo date('Y/m/d', strtotime($listing['created_at'])); ?>
                                            </p>
                                            <div class="d-flex justify-content-between">
                                                <a href="listing.php?id=<?php echo $listing['id']; ?>" class="btn btn-sm btn-outline-primary">عرض التفاصيل</a>
                                                <a href="edit-listing.php?id=<?php echo $listing['id']; ?>" class="btn btn-sm btn-outline-secondary">تعديل</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?> 