<?php
require_once __DIR__ . '/includes/header.php';

$error = '';
$success = false;
$token = clean($_GET['token'] ?? '');

if (empty($token)) {
    redirect('forgot-password.php');
}

// Check if token exists and is valid
$stmt = $pdo->prepare("
    SELECT pr.*, u.email, u.username 
    FROM password_resets pr 
    JOIN users u ON pr.user_id = u.id 
    WHERE pr.token = ? AND pr.expires_at > NOW() AND pr.used = 0
");
$stmt->execute([$token]);
$reset = $stmt->fetch();

if (!$reset) {
    $error = 'رابط إعادة تعيين كلمة المرور غير صالح أو منتهي الصلاحية.';
} else {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $password = $_POST['password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';
        
        if (empty($password)) {
            $error = 'يرجى إدخال كلمة المرور الجديدة';
        } elseif (strlen($password) < 8) {
            $error = 'يجب أن تكون كلمة المرور 8 أحرف على الأقل';
        } elseif ($password !== $confirm_password) {
            $error = 'كلمات المرور غير متطابقة';
        } else {
            // Update password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
            $stmt->execute([$hashed_password, $reset['user_id']]);
            
            // Mark token as used
            $stmt = $pdo->prepare("UPDATE password_resets SET used = 1 WHERE token = ?");
            $stmt->execute([$token]);
            
            // Send confirmation email
            $to = $reset['email'];
            $subject = 'تم تغيير كلمة المرور - ' . SITE_NAME;
            $message = "
                <html dir='rtl'>
                <head>
                    <title>تم تغيير كلمة المرور</title>
                </head>
                <body>
                    <h2>مرحباً {$reset['username']}</h2>
                    <p>تم تغيير كلمة المرور الخاصة بك بنجاح.</p>
                    <p>إذا لم تقم بهذا التغيير، يرجى الاتصال بنا فوراً.</p>
                    <br>
                    <p>مع تحيات،<br>فريق " . SITE_NAME . "</p>
                </body>
                </html>
            ";
            
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
            $headers .= "From: " . SITE_NAME . " <" . ADMIN_EMAIL . ">" . "\r\n";
            
            mail($to, $subject, $message, $headers);
            
            $success = true;
        }
    }
}
?>

<div class="container py-5">
    <div class="row">
        <div class="col-lg-6 mx-auto">
            <div class="card shadow">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0">إعادة تعيين كلمة المرور</h4>
                </div>
                <div class="card-body">
                    <?php if ($error): ?>
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-circle me-2"></i>
                            <?php echo $error; ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($success): ?>
                        <div class="alert alert-success">
                            <i class="fas fa-check-circle me-2"></i>
                            تم تغيير كلمة المرور بنجاح. يمكنك الآن تسجيل الدخول باستخدام كلمة المرور الجديدة.
                        </div>
                        <div class="text-center">
                            <a href="login.php" class="btn btn-primary">
                                <i class="fas fa-sign-in-alt me-2"></i>
                                تسجيل الدخول
                            </a>
                        </div>
                    <?php elseif (!$error): ?>
                        <form method="POST" action="" class="needs-validation" novalidate>
                            <div class="mb-3">
                                <label for="password" class="form-label">كلمة المرور الجديدة</label>
                                <input type="password" class="form-control" id="password" name="password" required
                                       minlength="8">
                                <div class="form-text">
                                    يجب أن تكون كلمة المرور 8 أحرف على الأقل
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="confirm_password" class="form-label">تأكيد كلمة المرور</label>
                                <input type="password" class="form-control" id="confirm_password" name="confirm_password" required
                                       minlength="8">
                            </div>
                            
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-key me-2"></i>
                                تغيير كلمة المرور
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Form validation
(function() {
    'use strict';
    var forms = document.querySelectorAll('.needs-validation');
    Array.prototype.slice.call(forms).forEach(function(form) {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
    });
})();
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?> 