-- Add phone column to users table if it doesn't exist
ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `phone` varchar(20) DEFAULT NULL AFTER `email`; 