-- Temporarily disable foreign key checks
SET FOREIGN_KEY_CHECKS = 0;

-- Create categories table if not exists
CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(100) NOT NULL UNIQUE,
    parent_id INT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (parent_id) REFERENCES categories(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Clear existing categories
DELETE FROM categories;
ALTER TABLE categories AUTO_INCREMENT = 1;

-- Insert main categories
INSERT INTO categories (name, slug, parent_id) VALUES
('آلات موسيقية', 'musical-instruments', NULL),
('أثاث منزلي', 'home-furniture', NULL),
('ألعاب فيديو', 'video-games', NULL),
('إلكترونيات', 'electronics', NULL),
('حيوانات أليفة', 'pets', NULL),
('خدمات', 'services', NULL),
('دراجات', 'bikes', NULL),
('ساعات ومجوهرات', 'watches-jewelry', NULL),
('سفر وسياحة', 'travel-tourism', NULL),
('سماعات وصوتيات', 'audio-headphones', NULL),
('سيارات', 'cars', NULL),
('عقارات', 'real-estate', NULL),
('كاميرات', 'cameras', NULL),
('كتب', 'books', NULL),
('كمبيوتر', 'computers', NULL),
('مستلزمات أطفال', 'kids-items', NULL),
('مطاعم وكافيهات', 'restaurants-cafes', NULL),
('ملابس', 'clothing', NULL),
('هدايا', 'gifts', NULL),
('وظائف', 'jobs', NULL);

-- Get IDs of main categories
SET @music_id = (SELECT id FROM categories WHERE name = 'آلات موسيقية');
SET @furniture_id = (SELECT id FROM categories WHERE name = 'أثاث منزلي');
SET @gaming_id = (SELECT id FROM categories WHERE name = 'ألعاب فيديو');
SET @electronics_id = (SELECT id FROM categories WHERE name = 'إلكترونيات');
SET @pets_id = (SELECT id FROM categories WHERE name = 'حيوانات أليفة');
SET @services_id = (SELECT id FROM categories WHERE name = 'خدمات');
SET @bikes_id = (SELECT id FROM categories WHERE name = 'دراجات');
SET @watches_id = (SELECT id FROM categories WHERE name = 'ساعات ومجوهرات');
SET @travel_id = (SELECT id FROM categories WHERE name = 'سفر وسياحة');
SET @audio_id = (SELECT id FROM categories WHERE name = 'سماعات وصوتيات');
SET @cars_id = (SELECT id FROM categories WHERE name = 'سيارات');
SET @realestate_id = (SELECT id FROM categories WHERE name = 'عقارات');
SET @cameras_id = (SELECT id FROM categories WHERE name = 'كاميرات');
SET @books_id = (SELECT id FROM categories WHERE name = 'كتب');
SET @computers_id = (SELECT id FROM categories WHERE name = 'كمبيوتر');
SET @kids_id = (SELECT id FROM categories WHERE name = 'مستلزمات أطفال');
SET @restaurants_id = (SELECT id FROM categories WHERE name = 'مطاعم وكافيهات');
SET @clothes_id = (SELECT id FROM categories WHERE name = 'ملابس');
SET @gifts_id = (SELECT id FROM categories WHERE name = 'هدايا');
SET @jobs_id = (SELECT id FROM categories WHERE name = 'وظائف');

-- Insert subcategories
INSERT INTO categories (name, slug, parent_id) VALUES
-- آلات موسيقية
('كمان', 'violin', @music_id),
('بيانو', 'piano', @music_id),
('أورغ', 'organ', @music_id),
('غيتار', 'guitar', @music_id),
('طبلة', 'drum', @music_id),
('عود', 'oud', @music_id),
('درامز', 'drums', @music_id),

-- أثاث منزلي
('غرف نوم', 'bedrooms', @furniture_id),
('غرف جلوس', 'living-rooms', @furniture_id),
('مطابخ', 'kitchens', @furniture_id),
('طاولات طعام', 'dining-tables', @furniture_id),
('كراسي', 'chairs', @furniture_id),
('خزائن', 'cabinets', @furniture_id),

-- ألعاب فيديو
('بلايستيشن', 'playstation', @gaming_id),
('إكس بوكس', 'xbox', @gaming_id),
('نينتندو', 'nintendo', @gaming_id),
('ألعاب كمبيوتر', 'pc-games', @gaming_id),
('ألعاب موبايل', 'mobile-games', @gaming_id),

-- إلكترونيات
('هواتف محمولة', 'mobile-phones', @electronics_id),
('لابتوب', 'laptops', @electronics_id),
('أجهزة كمبيوتر مكتبي', 'desktop-computers', @electronics_id),
('شاشات', 'monitors', @electronics_id),
('أجهزة تابلت', 'tablets', @electronics_id),
('أكسسوارات إلكترونية', 'electronics-accessories', @electronics_id),

-- حيوانات أليفة
('كلاب', 'dogs', @pets_id),
('قطط', 'cats', @pets_id),
('طيور', 'birds', @pets_id),
('أسماك', 'fish', @pets_id),
('مستلزمات حيوانات', 'pet-supplies', @pets_id),

-- خدمات
('خدمات منزلية', 'home-services', @services_id),
('خدمات نقل', 'transportation-services', @services_id),
('خدمات صيانة', 'maintenance-services', @services_id),
('خدمات تصميم', 'design-services', @services_id),
('خدمات توصيل', 'delivery-services', @services_id),

-- دراجات
('دراجات هوائية', 'bicycles', @bikes_id),
('دراجات نارية', 'motorcycles', @bikes_id),
('مستلزمات الدراجات', 'bike-accessories', @bikes_id),

-- ساعات ومجوهرات
('ساعات رجالية', 'mens-watches', @watches_id),
('ساعات نسائية', 'womens-watches', @watches_id),
('أطقم مجوهرات', 'jewelry-sets', @watches_id),
('خواتم', 'rings', @watches_id),
('أساور', 'bracelets', @watches_id),
('سلاسل', 'necklaces', @watches_id),

-- سفر وسياحة
('حجز فنادق', 'hotel-booking', @travel_id),
('جولات سياحية', 'tour-packages', @travel_id),
('تذاكر طيران', 'flight-tickets', @travel_id),
('تأشيرات سفر', 'travel-visas', @travel_id),
('وجهات سياحية', 'tourist-destinations', @travel_id),

-- سماعات وصوتيات
('سماعات أذن', 'earphones', @audio_id),
('سماعات رأس', 'headphones', @audio_id),
('مكبرات صوت', 'speakers', @audio_id),
('أنظمة صوت منزلية', 'home-audio-systems', @audio_id),

-- سيارات
('سيارات للبيع', 'cars-for-sale', @cars_id),
('سيارات للإيجار', 'cars-for-rent', @cars_id),
('قطع غيار', 'spare-parts', @cars_id),
('إكسسوارات سيارات', 'car-accessories', @cars_id),
('دراجات نارية', 'motorcycles-cars', @cars_id),

-- عقارات
('شقق للبيع', 'apartments-for-sale', @realestate_id),
('شقق للإيجار', 'apartments-for-rent', @realestate_id),
('أراضي', 'land', @realestate_id),
('فيلات', 'villas', @realestate_id),
('محلات تجارية', 'commercial-shops', @realestate_id),

-- كاميرات
('كاميرات رقمية', 'digital-cameras', @cameras_id),
('كاميرات مراقبة', 'surveillance-cameras', @cameras_id),
('كاميرات احترافية', 'professional-cameras', @cameras_id),
('عدسات كاميرات', 'camera-lenses', @cameras_id),

-- كتب
('كتب تعليمية', 'educational-books', @books_id),
('كتب روايات', 'novels', @books_id),
('كتب أطفال', 'children-books', @books_id),
('كتب دينية', 'religious-books', @books_id),

-- كمبيوتر
('شاشات كمبيوتر', 'computer-monitors', @computers_id),
('كيبوردات', 'keyboards', @computers_id),
('ماوسات', 'mice', @computers_id),
('قطع كمبيوتر', 'computer-parts', @computers_id),
('برامج', 'software', @computers_id),

-- مستلزمات أطفال
('ملابس أطفال', 'kids-clothing-items', @kids_id),
('ألعاب أطفال', 'kids-toys', @kids_id),
('عربات أطفال', 'strollers', @kids_id),
('كراسي أطفال', 'kids-chairs', @kids_id),
('مستلزمات حديثي الولادة', 'newborn-supplies', @kids_id),

-- مطاعم وكافيهات
('مطاعم', 'restaurants', @restaurants_id),
('كافيهات', 'cafes', @restaurants_id),
('خدمات تموين', 'catering-services', @restaurants_id),
('أدوات مطاعم', 'restaurant-equipment', @restaurants_id),

-- ملابس
('ملابس رجالية', 'mens-clothing', @clothes_id),
('ملابس نسائية', 'womens-clothing', @clothes_id),
('ملابس أطفال', 'kids-clothing', @clothes_id),
('أحذية', 'shoes', @clothes_id),
('حقائب', 'bags', @clothes_id),

-- هدايا
('هدايا رجالية', 'mens-gifts', @gifts_id),
('هدايا نسائية', 'womens-gifts', @gifts_id),
('هدايا أطفال', 'kids-gifts', @gifts_id),
('صناديق هدايا', 'gift-boxes', @gifts_id),

-- وظائف
('وظائف إدارية', 'administrative-jobs', @jobs_id),
('وظائف تقنية', 'technical-jobs', @jobs_id),
('وظائف تعليمية', 'educational-jobs', @jobs_id),
('وظائف طبية', 'medical-jobs', @jobs_id),
('وظائف تسويق', 'marketing-jobs', @jobs_id),
('وظائف حرة', 'freelance-jobs', @jobs_id);

-- Re-enable foreign key checks
SET FOREIGN_KEY_CHECKS = 1; 