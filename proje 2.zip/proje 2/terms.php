<?php
require_once __DIR__ . '/includes/header.php';
?>

<div class="container py-5">
    <div class="row">
        <div class="col-lg-8 mx-auto">
            <div class="card shadow">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0">شروط الاستخدام</h4>
                </div>
                <div class="card-body">
                    <div class="mb-4">
                        <h5 class="text-primary">مقدمة</h5>
                        <p>مرحباً بك في KREZMO. باستخدامك لمنصتنا، فإنك توافق على الالتزام بشروط الاستخدام هذه. يرجى قراءة هذه الشروط بعناية قبل استخدام المنصة.</p>
                    </div>

                    <div class="mb-4">
                        <h5 class="text-primary">التسجيل والحساب</h5>
                        <ul class="list-unstyled">
                            <li class="mb-2">
                                <i class="fas fa-check-circle text-success me-2"></i>
                                يجب أن تكون فوق 18 عاماً لإنشاء حساب
                            </li>
                            <li class="mb-2">
                                <i class="fas fa-check-circle text-success me-2"></i>
                                تقديم معلومات صحيحة ودقيقة
                            </li>
                            <li class="mb-2">
                                <i class="fas fa-check-circle text-success me-2"></i>
                                الحفاظ على سرية حسابك وكلمة المرور
                            </li>
                            <li class="mb-2">
                                <i class="fas fa-check-circle text-success me-2"></i>
                                إخطارنا فوراً بأي استخدام غير مصرح به
                            </li>
                        </ul>
                    </div>

                    <div class="mb-4">
                        <h5 class="text-primary">قواعد النشر</h5>
                        <p>عند نشر إعلان، يجب الالتزام بالقواعد التالية:</p>
                        <ul class="list-unstyled">
                            <li class="mb-2">
                                <i class="fas fa-check-circle text-success me-2"></i>
                                تقديم وصف دقيق وصادق للسلعة أو الخدمة
                            </li>
                            <li class="mb-2">
                                <i class="fas fa-check-circle text-success me-2"></i>
                                استخدام صور حقيقية وحديثة
                            </li>
                            <li class="mb-2">
                                <i class="fas fa-check-circle text-success me-2"></i>
                                تحديد السعر بشكل واضح وصحيح
                            </li>
                            <li class="mb-2">
                                <i class="fas fa-check-circle text-success me-2"></i>
                                عدم نشر محتوى مخالف للقوانين أو الأخلاق
                            </li>
                        </ul>
                    </div>

                    <div class="mb-4">
                        <h5 class="text-primary">المحتوى المحظور</h5>
                        <p>يحظر نشر المحتوى التالي:</p>
                        <ul class="list-unstyled">
                            <li class="mb-2">
                                <i class="fas fa-times-circle text-danger me-2"></i>
                                المواد الإباحية أو المسيئة
                            </li>
                            <li class="mb-2">
                                <i class="fas fa-times-circle text-danger me-2"></i>
                                السلع المقلدة أو المزورة
                            </li>
                            <li class="mb-2">
                                <i class="fas fa-times-circle text-danger me-2"></i>
                                الأسلحة والمتفجرات
                            </li>
                            <li class="mb-2">
                                <i class="fas fa-times-circle text-danger me-2"></i>
                                المخدرات والمواد المحظورة
                            </li>
                        </ul>
                    </div>

                    <div class="mb-4">
                        <h5 class="text-primary">المسؤولية القانونية</h5>
                        <p>أنت مسؤول عن:</p>
                        <ul class="list-unstyled">
                            <li class="mb-2">
                                <i class="fas fa-check-circle text-success me-2"></i>
                                الالتزام بجميع القوانين المحلية والدولية
                            </li>
                            <li class="mb-2">
                                <i class="fas fa-check-circle text-success me-2"></i>
                                دقة المعلومات التي تقدمها
                            </li>
                            <li class="mb-2">
                                <i class="fas fa-check-circle text-success me-2"></i>
                                أي ضرر يلحق بالآخرين نتيجة استخدامك للمنصة
                            </li>
                        </ul>
                    </div>

                    <div class="mb-4">
                        <h5 class="text-primary">حقوق الملكية الفكرية</h5>
                        <p>جميع المحتوى على المنصة محمي بموجب حقوق الملكية الفكرية. لا يجوز:</p>
                        <ul class="list-unstyled">
                            <li class="mb-2">
                                <i class="fas fa-times-circle text-danger me-2"></i>
                                نسخ أو توزيع المحتوى دون إذن
                            </li>
                            <li class="mb-2">
                                <i class="fas fa-times-circle text-danger me-2"></i>
                                استخدام العلامات التجارية أو الشعارات
                            </li>
                            <li class="mb-2">
                                <i class="fas fa-times-circle text-danger me-2"></i>
                                إعادة نشر الإعلانات دون موافقة
                            </li>
                        </ul>
                    </div>

                    <div class="mb-4">
                        <h5 class="text-primary">إنهاء الخدمة</h5>
                        <p>يحق لنا:</p>
                        <ul class="list-unstyled">
                            <li class="mb-2">
                                <i class="fas fa-check-circle text-success me-2"></i>
                                تعليق أو إنهاء حسابك في حالة المخالفة
                            </li>
                            <li class="mb-2">
                                <i class="fas fa-check-circle text-success me-2"></i>
                                حذف أي محتوى مخالف
                            </li>
                            <li class="mb-2">
                                <i class="fas fa-check-circle text-success me-2"></i>
                                رفض تقديم الخدمة لأي مستخدم
                            </li>
                        </ul>
                    </div>

                    <div class="mb-4">
                        <h5 class="text-primary">التغييرات على الشروط</h5>
                        <p>قد نقوم بتحديث شروط الاستخدام من وقت لآخر. سيتم إخطارك بأي تغييرات جوهرية من خلال البريد الإلكتروني أو إشعار على المنصة.</p>
                    </div>

                    <div class="mb-4">
                        <h5 class="text-primary">اتصل بنا</h5>
                        <p>إذا كان لديك أي أسئلة حول شروط الاستخدام، يرجى التواصل معنا عبر:</p>
                        <p class="mb-0">
                            <i class="fas fa-envelope text-primary me-2"></i>
                            <?php echo ADMIN_EMAIL; ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?> 